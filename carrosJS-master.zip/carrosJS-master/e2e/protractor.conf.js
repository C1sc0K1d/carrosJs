// @ts-check
// Protractor configuration file, see link for more information
// https://github.com/angular/protractor/blob/master/lib/config.ts

//bring in node os module to determine appropriate paths for drivers
var os = require('os');
var osType = os.platform();

var extension = "";
if(osType === 'win32') {
	extension = ".exe";
}
const {SpecReporter} = require('jasmine-spec-reporter');

/**
 * @type { import("protractor").Config }
 */
exports.config = {
	allScriptsTimeout: 11000,
	specs: [
		'./src/**/*.e2e-spec.ts'
	],
	capabilities: {
		'browserName': 'chrome',
		'chromeOptions': {
			'args': ['--headless', '--no-sandbox', '--disable-dev-shm-usage'],
			'binary': require('puppeteer').executablePath()
		}
	},
	directConnect: true,
	chromeDriver: '../node_modules/protractor/selenium/chromedriver' + extension,
	geckoDriver: '../node_modules/protractor/selenium/geckodriver' + extension,

	baseUrl: 'http://localhost:9500',

	framework: 'jasmine',

	jasmineNodeOpts: {
		showColors: true,
		defaultTimeoutInterval: 30000,
		print: function () {}
	},

	onPrepare() {
		require('ts-node').register({
			project: require('path').join(__dirname, './tsconfig.json')
		});

		jasmine.getEnv().addReporter(new SpecReporter({ spec: { displayStacktrace: true } }));

		global.EC = protractor.ExpectedConditions;
	}
};