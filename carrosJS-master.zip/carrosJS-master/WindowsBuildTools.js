const fs = require('fs');
const os = require('os');
const https = require('https');
const osType = os.platform();
const path = require('path');
const spawn = require('child_process').spawn;

//helper function for handling HTTP get
//based on this stackoverflow post https://stackoverflow.com/a/22907134
const downloadFile = function(url, dest, cb) {
	const file = fs.createWriteStream(dest);
	https.get(url, function(response) {
		response.pipe(file);
		file.on('finish', function() {
			console.log('Downloaded ', url, 'to ', dest, ' successfully \n');
			file.close(cb);
		});
	}).on('error', function(err) {
		fs.unlink(dest);
		console.error(err.message);
		if (cb) cb(err.message);
	});
};

//The Visual Studio Windows Build Tools and Python are only required for the Windows platform
if(osType === 'win32') {
	const nexusUrl = 'https://www.nexus.ford.com/repository/wamcoe_raw_private_repository/';

	const windowsBuildToolsLocation = './.windows-build-tools';
	//write stream bails out if the folder doesn't exist. make it first.
	if(!fs.existsSync(windowsBuildToolsLocation)) {
		fs.mkdirSync(windowsBuildToolsLocation);
	}

	const pythonVersion = '2.7.15';
	const pythonFileName = 'python-' + pythonVersion + '.amd64.msi';
	const pythonLocalPath = path.join(windowsBuildToolsLocation, pythonFileName);


	// offline installer created with the following command:
	// .\vs_BuildTools.exe --layout C:\VSBuildTools2017 --add Microsoft.VisualStudio.Workload.MSBuildTools --includeRecommended
	// https://docs.microsoft.com/en-us/visualstudio/install/create-a-network-installation-of-visual-studio?view=vs-2019#create-an-offline-installation-folder
	const buildToolsVersion = 'VisualStudio_2017';
	const buildToolsFileNameSuffix = '_BuildTools';
	const buildToolsFileNameExtension= '.zip';
	const buildToolsFileName = buildToolsVersion + buildToolsFileNameSuffix;
	const buildToolsFullFileName = buildToolsVersion + buildToolsFileNameSuffix + buildToolsFileNameExtension;
	const buildToolsLocalPath = path.join(windowsBuildToolsLocation, buildToolsFullFileName);

	const buildToolsUnzip = function(FileName) {
		console.log("Unzipping " + buildToolsFullFileName + ".  Please wait \n");
		//no unzip support in vanilla node. default back to the command line
		const unzip = spawn('7z', ['x', buildToolsFullFileName, '-aoa', '-o' + buildToolsFileName], {
			cwd: windowsBuildToolsLocation,
			shell: true
		});

		unzip.stderr.on('data', function (data) {
			console.log(buildToolsFullFileName, ' stderr: ', data);
		});

		unzip.on('close', function (code) {
			console.log(buildToolsFullFileName, ' Unzip process exited with code ', code);
			count++;
		});
	};

	let count = 0;
	if(!fs.existsSync(pythonLocalPath)) {
		console.log("Downloading " + pythonFileName + "\n");
		downloadFile(nexusUrl + 'windows-build-tools/' + pythonFileName, pythonLocalPath, function(res) {
			count++;
		});
	} else {
		console.log(pythonFileName + " already downloaded.\n");
		count++;
	}
	if(!fs.existsSync(buildToolsLocalPath)) {
		console.log("Downloading " + buildToolsFullFileName + '.  This will take a few minutes. \n');
		downloadFile(nexusUrl + "windows-build-tools/" + buildToolsFullFileName, buildToolsLocalPath, buildToolsUnzip.bind(this, buildToolsFullFileName));
	} else {
		console.log(buildToolsFullFileName + " already downloaded. Moving to unzip step\n");
		buildToolsUnzip(buildToolsFullFileName);
	}

	const timer = setInterval(function() {
		if(count === 2) {
			console.log('Installing Python ' + pythonVersion + '.  A Python installer window will now appear to show ' +
				'installation progress. Please wait. If you did not run this script as an administrator, please click ' +
				'\'Yes\' when the windows UAC Prompt appears.  Thank you :) \n\n');

			const pwd = process.cwd();
			let installCmd = '.\\.windows-build-tools\\' + pythonFileName;
			// https://docs.python.org/3/using/windows.html#installing-without-ui
			let cmdArgs = [
				'DefaultJustForMeTargetDir=%userprofile%\\.windows_build_tools',
				'/passive',
				'PrependPath=1'
			];

			spawn(installCmd, cmdArgs, {stdio: 'inherit', shell: true})
				.on('error', function(err) {
						console.error(err);
					}
				)

				.on('close', function(code, signal){
						console.log('Finished installing Python ' + pythonVersion);
					}
				);

			console.log('Installing Visual Studio Build Tools.  The Visual Studio installer window will now appear in' +
				' order to show installation progress.  Please wait.  If you did not run this script as an administrator' +
				', please click \'Yes\' when the Windows UAC Prompt appears.  Thank you :) \n\n');
			clearInterval(timer);

			installCmd = '.\\.windows-build-tools\\' + buildToolsFileName + '\\vs_BuildTools.exe';
			// https://docs.microsoft.com/en-us/visualstudio/install/use-command-line-parameters-to-install-visual-studio?view=vs-2019#install-options
			cmdArgs = [
				'--add Microsoft.VisualStudio.Workload.MSBuildTools',
				'--includeRecommended',
				'--noWeb',
				'--passive',
				'--wait'
			];

			spawn(installCmd, cmdArgs, {stdio: 'inherit', shell: true})
				.on('error', function(err) {
						console.error(err);
					}
				)

				.on('close', function(code, signal){
						console.log('Finished installing ' + buildToolsVersion + ' Build Tools\n');
					}
				);
		}
	}, 500);
}
