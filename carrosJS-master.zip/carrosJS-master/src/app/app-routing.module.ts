import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {ExamplePageComponent} from './example-page/example-page.component';
import {NotFoundComponent} from './not-found/not-found.component';

const routes: Routes = [
	{
		path: 'example-page',
		component: ExamplePageComponent
	},
	{
		path: '',
		redirectTo: '/example-page',
		pathMatch: 'full'
	},
	{
		path: '404', component: NotFoundComponent
	},
	{
		path: '**', redirectTo: '/404'
	}
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})
export class AppRoutingModule {}
