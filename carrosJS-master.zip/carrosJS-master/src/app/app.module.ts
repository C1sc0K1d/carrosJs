import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {AppComponent} from './app.component';
import {NavComponent} from './nav/nav.component';
import {ButtonModule} from 'primeng/button';
import {MenubarModule} from 'primeng/menubar';
import {PanelMenuModule} from 'primeng/panelmenu';
import {SidebarModule} from 'primeng/sidebar';
import {AppRoutingModule} from './app-routing.module';
import {ExamplePageComponent} from './example-page/example-page.component';
import {ToastModule} from 'primeng/toast';
import {NotFoundComponent} from './not-found/not-found.component';
import {MessageService} from 'primeng/api';

@NgModule({
	declarations: [
		AppComponent,
		NavComponent,
		ExamplePageComponent,
		NotFoundComponent
	],
	imports: [
		BrowserModule,
		BrowserAnimationsModule,
		RouterModule,
		AppRoutingModule,
		ButtonModule,
		MenubarModule,
		PanelMenuModule,
		SidebarModule,
		ToastModule
	],
	providers: [
		MessageService
	],
	bootstrap: [AppComponent]
})
export class AppModule {
}
