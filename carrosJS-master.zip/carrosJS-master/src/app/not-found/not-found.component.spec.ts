import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {NotFoundComponent} from './not-found.component';
import {By} from '@angular/platform-browser';
import {RouterLinkStubDirective} from '../../testing/router-stubs';

describe('NotFoundComponent', () => {
	let component: NotFoundComponent;
	let fixture: ComponentFixture<NotFoundComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [
				NotFoundComponent,
				RouterLinkStubDirective
			]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(NotFoundComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	describe('template tests', () => {
		it('should have 404 h1 tag', () => {
			expect(fixture.debugElement.query(By.css('h1')).nativeElement.innerHTML).toEqual('404 - Page Not Found');
		});

		it('should have link to home page', () => {
			const a = fixture.debugElement.query(By.css('a'));
			const span = a.query(By.css('span'));

			expect(a.nativeElement.attributes.getNamedItem('href').value).toEqual('/');
			expect(a.nativeElement.attributes.getNamedItem('class').value)
				.toEqual('mt-2 ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
			expect(span.nativeNode.textContent).toEqual('Go To Homepage');
			expect(a.childNodes[0].nativeNode.attributes.getNamedItem('class').value)
				.toEqual('ui-button-text ui-clickable');
		});
	});
});
